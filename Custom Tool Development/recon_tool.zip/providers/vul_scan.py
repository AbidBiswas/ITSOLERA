import requests

def scan(target_url):
    print(f"[*] Running basic vulnerability scan for {target_url}...")
    vulnerabilities = []

    if not target_url.startswith(("http://", "https://")):
        target_url = "http://" + target_url

    try:
        response = requests.get(f"{target_url}/.env", timeout=3)
        if response.status_code == 200 and "APP_KEY" in response.text:
            vulnerabilities.append(f"Potentially exposed .env file at {target_url}/.env")
    except requests.exceptions.RequestException:
        pass

    try:
        response = requests.get(f"{target_url}/.git/config", timeout=3)
        if response.status_code == 200 and "[core]" in response.text:
            vulnerabilities.append(f"Potentially exposed Git repository at {target_url}/.git/config")
    except requests.exceptions.RequestException:
        pass

    if not vulnerabilities:
        vulnerabilities.append("No obvious vulnerabilities found by this basic scan.")

    return vulnerabilities
