import yaml
import argparse
from providers import whois_lookup, dns_enum, crtsh, hackertarget, active_recon, port_scan, dir_enum, vul_scan

def load_config():
    with open("config/sources.yaml", "r") as f:
        return yaml.safe_load(f)

def main(domain, whois_flag, dns_flag, subdomains_flag, active_flag, ports_flag, dirs_flag, vulns_flag):
    config = load_config()

    print(f"[*] Starting reconnaissance for: {domain}\n")

    if whois_flag:
        print("--- WHOIS Lookup ---")
        whois_data = whois_lookup.lookup(domain)
        print(whois_data)
        print("-" * 20 + "\n")

    if dns_flag:
        print("--- DNS Enumeration ---")
        dns_data = dns_enum.enum(domain)
        for record_type, records in dns_data.items():
            print(f"  {record_type} Records:")
            if isinstance(records, list):
                for r in records:
                    print(f"    - {r}")
            else:
                print(f"    {records}")
        print("-" * 20 + "\n")

    if subdomains_flag:
        print("--- Subdomain Enumeration ---")
        all_subdomains = set()
        if config.get("crtsh", {}).get("enabled"):
            print("[*] Using crt.sh...")
            subs = crtsh.search(domain)
            all_subdomains.update(subs)

        if config.get("hackertarget", {}).get("enabled"):
            print("[*] Using HackerTarget...")
            subs = hackertarget.search(domain)
            all_subdomains.update(subs)

        print(f"\n[+] Total unique subdomains found: {len(all_subdomains)}")
        for sub in sorted(all_subdomains):
            print(f"  - {sub}")
        print("-" * 20 + "\n")

    if active_flag:
        print("--- Active Reconnaissance (Basic) ---")
        active_recon.run_active_recon(domain)
        print("-" * 20 + "\n")

    if ports_flag:
        print("--- Port Scanning ---")
        open_ports = port_scan.scan(domain)
        if open_ports:
            print("[+] Open Ports:")
            for port, service in open_ports.items():
                print(f"  - Port {port}: {service}")
        else:
            print("No open ports found or scan not performed.")
        print("-" * 20 + "\n")

    if dirs_flag:
        print("--- Directory and File Enumeration ---")
        found_paths = dir_enum.enumerate(domain)
        if found_paths:
            print("[+] Found Directories/Files:")
            for path in found_paths:
                print(f"  - {path}")
        else:
            print("No significant directories or files found.")
        print("-" * 20 + "\n")

    if vulns_flag:
        print("--- Basic Vulnerability Scan ---")
        vulnerabilities = vul_scan.scan(domain)
        if vulnerabilities:
            print("[+] Potential Vulnerabilities:")
            for vuln in vulnerabilities:
                print(f"  - {vuln}")
        else:
            print("No immediate vulnerabilities detected by basic scan.")
        print("-" * 20 + "\n")

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="A comprehensive reconnaissance tool.")
    parser.add_argument("domain", help="Target domain (e.g., example.com)")
    parser.add_argument("--whois", action="store_true", help="Perform WHOIS lookup")
    parser.add_argument("--dns", action="store_true", help="Perform DNS enumeration (A, MX, TXT, NS)")
    parser.add_argument("--subdomains", action="store_true", help="Enumerate subdomains via APIs (crt.sh, HackerTarget)")
    parser.add_argument("--active", action="store_true", help="Run active reconnaissance (e.g., banner grabbing, basic tech detection)")
    parser.add_argument("--ports", action="store_true", help="Perform port scanning on common ports")
    parser.add_argument("--dirs", action="store_true", help="Perform directory and file enumeration")
    parser.add_argument("--vulns", action="store_true", help="Run a basic vulnerability scan")

    args = parser.parse_args()
    main(args.domain, args.whois, args.dns, args.subdomains, args.active, args.ports, args.dirs, args.vulns)
